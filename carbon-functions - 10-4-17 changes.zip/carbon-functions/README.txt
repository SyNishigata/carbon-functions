-----10/3/2017-----
My additions

1. Added "Database_Instructions.jpg" to help with installing the database to 
	your local machine


My changes:

1. Fixed emissions-fuel.php to now add and subtract properly

2. Changed emissions-motorcycle.php line 291 to line 292 so it matches new
	excel spreadsheet

3. Added km option to emissions-motorcycle.php and 'km' column to database

4. Changed emissions-gas.php lines 221, 225, 229 to 222, 226, 230 so it 
	matches new excel spreadsheet

5. Changed emissions-water.php lines 199, 206 to 200, 207 so it matches
	new excel spreadsheet

6. Changed emissions-food.php line 206 to lines 207-212 so it matches
	new excel spreadsheet

7. Added Yearly CO2 emissions (most recent record in the database for each
	specifc category) on ALL emission pages.

8. Added a Total CO2 emissions on index page: http://localhost/carbon-functions/



My notes:

1. In the gas emissions section of the spreadsheet there still isn't a formula
	for the units "therms" and "kwh"


--------------------------------------------------------------------------------

-----9/29/2017-----
All calculations are done in the following files:

*Food*
emissions-food.php //starting at line 195
*Home*
emissions-electric.php //starting at line 189
emissions-fuel.php //starting at line 189
emissions-gas.php //starting at line 188
emissions-water.php //starting at line 181
*Travel*
emissions-bus.php //starting at line 196
emissions-car.php //starting at line 323
emissions-motorcycle.php //starting at line 242
emissions-plane.php //strating at line 189
emissions-train.php //starting at line 197
*Waste*
emissions-waste.php //starting at line 164





These files have been corrected by me to match excel spreadsheet:

*emissions-gas.php // lines 200-218 changed to lines 219-235
*emissions-water.php // lines 197 and 203 changed to lines 199 and 205




These files I can't confirm their accuracy because don't match categories on the excel spreadsheet:

*emissions-food.php // spreadsheet combines food types and they are all measured by gCO2e/calorie
		       but our website calculates by how many times a week a person eats these foods
*emissions-fuel.php // spreadsheet's "Other Fuels" is measured by gCO2e/US$, our website calculates
		       by yearly gallon consumption
*emissions-gas.php // spreadsheet doesn't account for "kWh" unit measurement
*emissions-motorcycle.php // spreadsheet doesn't have motorcycle calculations
*emissions-waste.php // spreadsheet doesn't have waste calculations




These specific sections in spreadsheet don't correlate with the website http://www.coolcalifornia.org/ :

*emissions-food.php // the website uses an "average" scale and excel spreadsheet combines food types
*emissions-electric.php // website: 99999 kwh/y = 64.31 co2, spreadsheet: 99999kwh = 91.01 co2
*emissions-fuel.php // website: 1000 us$/year = 4.95 co2, spreadsheet says 1000usd = 0.68 co2. also 
		       our website calculates by gallons, not us$
*emissions-bus.php // website: 99999 miles/year = 0.14 co2, spreadsheet says 99999m = 37.80 co2




*My Report Summary*

Any file that was not listed above has been tested by me to both match the excel spreadsheet calculations
and match the results from the website http://www.coolcalifornia.org/


