<?php
$hostname = "localhost";
$database = "carbon_neutrality";
$username = "root";
$password = "";
?>