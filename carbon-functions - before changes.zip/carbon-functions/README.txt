PHP/Javascript that involves calculations are in the following files:
emissions-x.php  //where x = the section (i.e. food, electric, etc).

Ignore all other file as they developed for ranking/chart functionality.


** Result of my testing **
I have tested each calculation to make sure they match the functions 
listed in the excel spreadsheet.

These specific sections don't correlate with the website http://www.coolcalifornia.org/ :
*emissions-food.php // the website uses an "average" scale, so that might be the difference
*emissions-electric.php
*emissions-fuel.php // using the website's "heating oil and other fuels" says 1000 gallons/year
		    // is 14.68 co2, while our spreadsheet says 1000g/y is 0.68 co2.
*emissions-gas.php // 
